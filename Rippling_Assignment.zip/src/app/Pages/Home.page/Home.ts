import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AppStates } from '../../services/app.service';

@Component({
    selector: 'Home',
    templateUrl:'Home.html'
  })

export class Home implements OnInit {
    //expected from API
    public numOfRows:any = [{name:"A"},{name:"B"},{name:"C"},{name:"D"},{name:"E"},{name:"F"},{name:"G"},{name:"H"},{name:"I"},{name:"J"}];
    public numOfSeatsInEachRow:any = new Array(12)


    public selectedSeats:any = []
    public showSeatsSelection:boolean = false;
    public seatsData:any;    
    public selectedSeatsDetails:any = [];
    public activePerson:any;
    public activeSeatsCount:Number;
    public activeSessionSeats:any = [];
    public reset:boolean = false;

    public currentState:any;
    constructor(public AppStates:AppStates){
    }

    ngOnInit() {
        this.constructSeatsData().then(res=>{
            console.log(res)
            this.seatsData = res;
        })
    }
  

    startSelection(name,seatsCount,button){
        if(seatsCount.value > 20){
            alert("Please select below or equal to 20 seats at one time")
            return
        }
        name.disabled = true;
        seatsCount.disabled = true;
        button.disabled = true;
        
        this.activePerson = name.value;
        this.activeSeatsCount = seatsCount.value;
        this.showSeatsSelection = true;
    }


    checkIfExistsinActiveSession(seat){
        for(let p = 0;p<this.activeSessionSeats.length;p++){
            let ifExists:boolean = false
            if(this.activeSessionSeats[p].seatNo == seat.seatNo){
                return ifExists = true;
            }

            if(p == this.activeSessionSeats.length-1){
                return ifExists
            }
        }
    }

    addSelectedSeats(seat,elm){

        //To check if seats are already selected previously
        if(this.activeSessionSeats.length < 1 && seat.Available == false || (this.activeSessionSeats.length && seat.Available == false && !this.checkIfExistsinActiveSession(seat))){
            console.log("cannot select selected Seat")
            return            
        }        

        for(let a=0;a<this.activeSessionSeats.length;a++){
            if(this.activeSessionSeats[a].seatNo == seat.seatNo){
                seat.Available = true;                
                elm.style.backgroundColor = "white";
                this.activeSessionSeats.splice(this.activeSessionSeats.findIndex(x => x.seatNo==seat.seatNo),1);
                console.log(this.activeSessionSeats)
                console.log("Selected Seat removed")
                return
            }
        }
 
        elm.style.backgroundColor = "green"
        seat.Available = false;

        if(this.selectedSeatsDetails.length<1){
            let selectedSeat = {name:this.activePerson,seats:[]}
            selectedSeat.seats.push(seat);
            this.selectedSeatsDetails.push(selectedSeat);
            this.activeSessionSeats.push(seat)
            return
        }
        
        for(let p=0;p<this.selectedSeatsDetails.length;p++){
            if(this.selectedSeatsDetails[p].name == this.activePerson){
                this.selectedSeatsDetails[p].seats.push(seat)
                this.activeSessionSeats.push(seat)
            }
        }

    }


    constructSeatsData(){
        return new Promise((resolveOuter,reject)=>{
            let data = new Array();
            let seatsData:any = new Promise((resolve,reject)=>{
                let rowsLength = this.numOfRows.length;        
                for(let i=0;i<=rowsLength;i++){
                    for(let k=1;k<=this.numOfSeatsInEachRow.length;k++){
                        let seatNo = this.numOfRows[i].name+k;
                        data.push({seatNo:seatNo,seatRow:this.numOfRows[i].name,Available:true})
                    }    
                    if(i == rowsLength-1){
                        resolve(data)              
                    }
                };
            })
    
            //map with selected seats
            seatsData.then(res=>{
                for(let l=0;l<res.length;l++){
                    for(let m=0; m<this.selectedSeats.length;m++){
                        if(this.selectedSeats[m].seatNo == res[l].seatNo){
                            res[l].Available = false;                            
                        }
                    }
                    if(l == res.length-1){
                        resolveOuter(res)              
                    }
                }
            })
        })
    }


    submitSelectedSeats(){

        if(this.activeSessionSeats.length != this.activeSeatsCount){
            alert("Please select "+this.activeSeatsCount+" Seats to continue");
            return
        }


        for(let p=0;p<this.selectedSeatsDetails.length;p++){
            if(this.selectedSeatsDetails[p].name == this.activePerson){
                this.selectedSeatsDetails[p].seats = this.activeSessionSeats
                // this.activeSessionSeats.push(seat)
            }
        }

        // this.AppStates.currentState = JSON.parse(JSON.stringify(this.selectedSeatsDetails));
        this.AppStates.currentState = this.selectedSeatsDetails;
        this.showSeatsSelection = false;

        this.currentState = this.AppStates.currentState;
        //reset
        this.resetState();
        console.log(this.AppStates.currentState)
        setTimeout(f=>{
            this.reset = false
        },10)
    }

    resetState(){
        this.selectedSeatsDetails = [];
        this.activeSessionSeats = [];
        this.activePerson = "";
        this.reset = true;
    }


    getListOfSeats(seats){
        let selectedSeatsToString:any = [];
        let selectedSeats = seats.filter(seat=>{
            selectedSeatsToString.push(seat.seatNo)
        })
        return selectedSeatsToString.toString();
    }

}