import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { environment } from 'environments/environment';
import { AppStates } from './services/app.service';
import { Home } from './Pages/Home.page/Home'

/**
 * App Component
 * Top Level Component
 */
@Component({
  selector: 'app',
  encapsulation: ViewEncapsulation.None,
  template: `<Home></Home>`
})
export class AppComponent implements OnInit {
  public showDevModule: boolean = environment.showDevModule;

  constructor(
    public appState: AppStates
  ) {}

  public ngOnInit() {
    console.log('Initial App State');
  }

}

