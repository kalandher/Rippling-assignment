import { Injectable,EventEmitter } from '@angular/core';



@Injectable()
export class AppStates {

  private _currentState:any = [];


  //To pass data from thumbnails page to child page using states
  
  //currentState() saves select image details
  set currentState(state){
    this._currentState.push(state);
  }

  //currentState() returns earlier selected image details
  get currentState(){
    return this._currentState;
  }

}